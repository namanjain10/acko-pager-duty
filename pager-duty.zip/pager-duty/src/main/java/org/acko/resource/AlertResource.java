package org.acko.resource;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import org.acko.manager.TeamManager;
import org.acko.models.SendAlertRequest;
import org.acko.models.TeamCreationRequest;

@Path("/va/apis")
public class AlertResource {

    private final TeamManager teamManager;

    public AlertResource(TeamManager teamManager) {
        this.teamManager = teamManager;
    }

    @POST
    @Path("/team/create")
    public Response createTeam(TeamCreationRequest teamCreationRequest) {
        boolean status = teamManager.createTeam(teamCreationRequest);
        return status ? Response.ok()
                .build(): Response.serverError()
                .build();
    }

    @POST
    @Path("/send/alert")
    public Response sendAlert(SendAlertRequest sendAlertRequest) {
        boolean status = teamManager.sendAlert(sendAlertRequest);
        return status ? Response.ok()
                .build(): Response.serverError()
                .build();
    }
}
