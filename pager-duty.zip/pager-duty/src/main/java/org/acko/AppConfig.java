package org.acko;

import io.dropwizard.Configuration;

public class AppConfig extends Configuration {

}
