package org.acko.dao;

import java.util.UUID;
import java.util.stream.Collectors;
import org.acko.models.Developer;
import org.acko.models.Team;
import org.acko.models.persist.StoredDeveloper;
import org.acko.models.persist.StoredTeam;
//import org.hibernate.SessionFactory;

public class TeamDao {

//    private final SessionFactory sessionFactory;

    public void create(Team team) {
        try {

        } catch () {

        }
    }

    public Team get(String id) {
        return null;
    }

    private StoredTeam toWired(Team team) {
        return new StoredTeam(team.getId(), team.getName(),
                team.getDevelopers().stream()
                        .map(this::toWired)
                        .collect(Collectors.toList()));
    }

    private StoredDeveloper toWired(Developer developer) {
        return new StoredDeveloper(developer.getId(), developer.getName(), developer.getPhoneNumber());
    }

    private Team toWired(StoredTeam team) {
        return new Team(team.getId(), team.getName(), team.getDevelopers()
                .stream()
                .map(this::toWired)
                .collect(Collectors.toList())
        );
    }

    private Developer toWired(StoredDeveloper storedDeveloper) {
        return new Developer(storedDeveloper.getId(), storedDeveloper.getName(), storedDeveloper.getPhoneNumber());
    }
}
