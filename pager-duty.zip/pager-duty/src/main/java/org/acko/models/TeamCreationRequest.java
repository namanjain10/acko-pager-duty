package org.acko.models;

public class TeamCreationRequest {

    private final Team team;
    private final Developer developer;

    public TeamCreationRequest(Team team, Developer developer) {
        this.team = team;
        this.developer = developer;
    }

    public Team getTeam() {
        return team;
    }

    public Developer getDeveloper() {
        return developer;
    }
}
