package org.acko.models;

import java.util.List;

public class Team {

    private final String id;
    private final String name;
    private final List<Developer> developers;

    public Team(String id, String name, List<Developer> developers) {
        this.id = id;
        this.name = name;
        this.developers = developers;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Developer> getDevelopers() {
        return developers;
    }
}
