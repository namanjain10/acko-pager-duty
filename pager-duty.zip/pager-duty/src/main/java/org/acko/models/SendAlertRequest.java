package org.acko.models;

public class SendAlertRequest {

    private final String teamId;
    private final String message;

    public SendAlertRequest(String teamId, String message) {
        this.teamId = teamId;
        this.message = message;
    }

    public String getTeamId() {
        return teamId;
    }

    public String getMessage() {
        return message;
    }
}
