package org.acko.models.persist;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table
public class StoredTeam {

    @Id
    @Column(name = "id", nullable = false)
    private String id;

    @Column
    private String name;

    @Column
    @OneToMany(mappedBy = "id")
    private List<StoredDeveloper> developers;

    public StoredTeam() {
    }

    public StoredTeam(String id, String name, List<StoredDeveloper> developers) {
        this.id = id;
        this.name = name;
        this.developers = developers;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<StoredDeveloper> getDevelopers() {
        return developers;
    }
}
