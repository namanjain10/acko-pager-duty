package org.acko;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.setup.Environment;
import java.util.Properties;
//import org.hibernate.SessionFactory;
//import org.hibernate.boot.Metadata;
//import org.hibernate.boot.MetadataSources;
//import org.hibernate.boot.registry.StandardServiceRegistry;
//import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App extends Application<Configuration> {

    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
    }

    public void run(Configuration configuration, Environment environment) throws Exception {

        Configuration config = new Configuration();
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder()
                .applySettings(getHibernateProperties())
                .build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
//        SessionFactory sessionFactory = new SessionFactory();
    }

    private Properties getHibernateProperties() {
        Properties props = new Properties();
        props.put("driver", "com.mysql.cj.jdbc.Driver");
        props.put("url", "jdbc:mysql://localhost:3306/pager_duty");
        props.put("user", "root");
        props.put("password", "password");
        props.put("dialect", "org.hibernate.dialect.MySql5Dialect");
        return props;
    }
}
