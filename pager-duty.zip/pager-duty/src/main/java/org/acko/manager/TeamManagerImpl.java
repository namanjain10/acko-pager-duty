package org.acko.manager;

import java.util.UUID;
import org.acko.dao.TeamDao;
import org.acko.models.SendAlertRequest;
import org.acko.models.Team;
import org.acko.models.TeamCreationRequest;

public class TeamManagerImpl implements TeamManager {

    private final TeamDao teamDao;

    public TeamManagerImpl(TeamDao teamDao) {
        this.teamDao = teamDao;
    }

    @Override
    public boolean createTeam(TeamCreationRequest teamCreationRequest) {
        exist = getTeamWithName(n);
        Team team = new Team(UUID.randomUUID().toString(), teamCreationRequest.getTeam().getName(),
                teamCreationRequest.getTeam()
                .getDevelopers());
        teamDao.create(team);
        return true;
    }

    @Override
    public Team getTeam(String id) {
        return null;
    }

    @Override
    public boolean sendAlert(SendAlertRequest sendAlertRequest) {
        return false;
    }
}
