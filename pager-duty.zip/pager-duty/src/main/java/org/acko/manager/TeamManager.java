package org.acko.manager;

import org.acko.models.SendAlertRequest;
import org.acko.models.Team;
import org.acko.models.TeamCreationRequest;

public interface TeamManager {

    boolean createTeam(TeamCreationRequest teamCreationRequest);

    Team getTeam(String id);

    boolean sendAlert(SendAlertRequest sendAlertRequest);
}
